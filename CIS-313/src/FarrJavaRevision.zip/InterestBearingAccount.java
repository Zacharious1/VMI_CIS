//Help received: none
public interface InterestBearingAccount {
    public void addInterest();
}

//Help received: none
public class NonInterestCheckingAccount extends Account{
   public NonInterestCheckingAccount() {
   }
}

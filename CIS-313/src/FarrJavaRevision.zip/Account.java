//Help received: none
public abstract class Account {
    private String name;
    private int accountNum;
    private double balance;

    public Account(String name, int accountNum, int balance) {
        this.name = name;
        this.accountNum = accountNum;
        this.balance = balance;
    }

    public Account() {}


    public String getName() { return name; }

    public int getAccountNum() { return accountNum; }

    public double getBalance() { return balance; }

    public void setName(String name) { this.name = name; }

    public void setAccountNum(int accountNum) { this.accountNum = accountNum; }

    public void setBalance(double balance) { this.balance = balance; }

    public void subBalance(double num) { if (this.getBalance() > num) this.balance -= num; }

    public void addBalance(double num) { this.balance += num; }



    @Override
    public String toString() {
        return "Account " + this.name + " , has account number " + this.accountNum + " and currently has a balance of $" + this.getBalance();
    }
}

//Help received: none
public class WalkupTicket extends FixedPriceTicket {
    public WalkupTicket() {
        this.setPrice(50);
    }

    @Override
    public String toString() {
        return super.toString();
    }

}

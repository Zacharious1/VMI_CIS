//Help received: none
public class ComplimentaryTicket extends FixedPriceTicket {
    public ComplimentaryTicket() {
        this.setPrice(0);
    }

    @Override
    public String toString() {
        return super.toString();
    }

}
